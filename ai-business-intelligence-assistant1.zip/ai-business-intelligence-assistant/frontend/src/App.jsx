import { useEffect, useMemo, useState } from 'react';

const API = import.meta.env.VITE_API_URL || 'http://127.0.0.1:8000';
const suggestions = [
  'What is the total revenue?',
  'Which product generated the highest revenue?',
  'Show the monthly revenue trend',
  'Which region generated the highest sales?',
  'Compare revenue between January 2026 and February 2026',
  'Show revenue by category',
  'Compare online and retail sales channels',
];

function formatValue(key, value) {
  if (value === null || value === undefined) return 'N/A';
  if (typeof value === 'number' && /revenue|change|percentage/i.test(key)) {
    if (/percentage/i.test(key)) return `${value > 0 ? '+' : ''}${value.toFixed(2)}%`;
    return `₹${value.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
  }
  return String(value);
}

export default function App() {
  const [question, setQuestion] = useState('');
  const [result, setResult] = useState(null);
  const [summary, setSummary] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => {
    fetch(`${API}/summary`).then(r => {
      if (!r.ok) throw new Error('Backend unavailable');
      return r.json();
    }).then(setSummary).catch(() => setError('Backend is not connected. Start FastAPI using the instructions in README.md.'));
  }, []);

  const monthlyRows = useMemo(() => result?.intent === 'monthly_revenue' ? result.data : [], [result]);
  const maxRevenue = Math.max(1, ...monthlyRows.map(r => Number(r.revenue || 0)));

  async function ask(value = question) {
    if (!value.trim()) return;
    setQuestion(value);
    setLoading(true);
    setError('');
    setResult(null);
    try {
      const response = await fetch(`${API}/ask`, {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ question: value }),
      });
      const body = await response.json();
      if (!response.ok) throw new Error(body.detail || 'The request failed.');
      setResult(body);
    } catch (e) {
      setError(e.message || 'Could not reach the backend.');
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="app-shell">
      <nav className="topbar">
        <a className="brand" href="#top"><span className="brand-mark">S</span><span>Sales<span className="brand-light"> Intelligence</span></span></a>
        <div className="top-status"><span className={`status-dot ${summary ? 'online' : ''}`}></span>{summary ? 'Database connected' : 'Connecting to database'}</div>
      </nav>

      <main id="top" className="main-content">
        <section className="hero">
          <div className="eyebrow"><span className="sparkle">✦</span> AI-POWERED BUSINESS ANALYTICS</div>
          <h1>Good decisions start<br /><span>with better questions.</span></h1>
          <p className="hero-copy">Explore your sales data in plain English. Ask a question and get an answer backed by real database calculations.</p>
        </section>

        {summary && <section className="metrics" aria-label="Dataset overview">
          <div className="metric-card"><span className="metric-label">RECORDS LOADED</span><strong>{summary.rows_loaded.toLocaleString('en-IN')}</strong><span className="metric-foot">Cleaned transactions</span></div>
          <div className="metric-card"><span className="metric-label">COMPLETED ORDERS</span><strong>{summary.completed_transactions.toLocaleString('en-IN')}</strong><span className="metric-foot">Included in revenue</span></div>
          <div className="metric-card"><span className="metric-label">TOTAL REVENUE</span><strong>₹{Number(summary.total_revenue).toLocaleString('en-IN', { maximumFractionDigits: 0 })}</strong><span className="metric-foot">After recorded discounts</span></div>
        </section>}

        <section className="ask-panel">
          <div className="panel-heading"><div><span className="section-kicker">ASK YOUR DATA</span><h2>What would you like to know?</h2></div><span className="ai-badge">✦ AI assistant</span></div>
          <form className="ask-form" onSubmit={e => { e.preventDefault(); ask(); }}>
            <span className="input-icon">⌕</span>
            <input value={question} onChange={e => setQuestion(e.target.value)} placeholder="e.g. Which product generated the highest revenue?" maxLength={500} aria-label="Ask a sales question" />
            <button className="ask-button" disabled={loading || !question.trim()}>{loading ? <><span className="spinner"></span>Thinking</> : <>Analyze <span>↗</span></>}</button>
          </form>
          <div className="suggestion-title">TRY A SUGGESTED QUESTION</div>
          <div className="suggestions">{suggestions.map(s => <button key={s} onClick={() => ask(s)} disabled={loading} className="suggestion">{s}<span>↗</span></button>)}</div>
        </section>

        {error && <div className="error-box"><strong>Connection notice</strong><span>{error}</span></div>}

        {result && <section className="result-panel">
          <div className="result-heading"><div><span className="section-kicker">YOUR RESULT</span><h2>{result.success ? 'Here’s what the data says' : 'Let’s try another question'}</h2></div><span className={`result-pill ${result.success ? 'success' : 'warning'}`}>{result.success ? '✓ Query complete' : 'Unsupported question'}</span></div>
          <p className="answer-text">{result.answer}</p>
          {result.success && result.data?.length > 0 && <div className="table-wrap"><table><thead><tr>{Object.keys(result.data[0]).map(k => <th key={k}>{k.replaceAll('_', ' ')}</th>)}</tr></thead><tbody>{result.data.map((row, i) => <tr key={i}>{Object.entries(row).map(([key, value]) => <td key={key}>{formatValue(key, value)}</td>)}</tr>)}</tbody></table></div>}
          {monthlyRows.length > 0 && <div className="chart"><div className="chart-title">Monthly revenue</div>{monthlyRows.map(row => <div className="bar-row" key={row.month}><span className="bar-month">{row.month}</span><div className="bar-track"><div className="bar-fill" style={{ width: `${Math.max(2, Number(row.revenue) / maxRevenue * 100)}%` }}></div></div><span className="bar-value">₹{Number(row.revenue).toLocaleString('en-IN')}</span></div>)}</div>}
          {result.success && <div className="provenance"><span className="provenance-icon">✓</span><span><strong>Database-backed answer</strong><br />The figures above are calculated from the sales database. Interpretation method: {result.interpretation_method === 'openai' ? 'LLM' : result.interpretation_method === 'rules_fallback' ? 'rule-based fallback' : 'rule-based classifier'}.</span></div>}
        </section>}

        <footer><span>SALES INTELLIGENCE</span><span>AI interprets · SQL calculates · You decide</span></footer>
      </main>
    </div>
  );
}
