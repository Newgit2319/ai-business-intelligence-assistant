import pytest
from fastapi.testclient import TestClient
from main import app
from database import get_connection


@pytest.fixture(scope="module")
def client():
    with TestClient(app) as test_client:
        yield test_client


def test_health_endpoint(client):
    response = client.get("/health")
    assert response.status_code == 200
    assert response.json()["status"] == "ok"
    assert response.json()["rows_loaded"] > 0


def test_total_revenue_question(client):
    response = client.post("/ask", json={"question": "What is the total revenue?"})
    assert response.status_code == 200
    body = response.json()
    assert body["success"] is True
    assert body["intent"] == "total_revenue"
    assert isinstance(body["data"][0]["revenue"], (int, float))


def test_highest_product_question(client):
    response = client.post("/ask", json={"question": "Which product generated the highest revenue?"})
    assert response.status_code == 200
    assert response.json()["intent"] == "highest_revenue_product"
    assert "product" in response.json()["data"][0]


def test_region_question(client):
    response = client.post("/ask", json={"question": "Which region generated the highest sales?"})
    assert response.status_code == 200
    assert response.json()["intent"] == "highest_sales_region"
    assert "region" in response.json()["data"][0]


def test_monthly_trend_question(client):
    response = client.post("/ask", json={"question": "Show the monthly revenue trend"})
    assert response.status_code == 200
    assert response.json()["intent"] == "monthly_revenue"
    assert len(response.json()["data"]) >= 1


def test_compare_two_months(client):
    response = client.post("/ask", json={"question": "Compare revenue between January 2026 and February 2026"})
    assert response.status_code == 200
    assert response.json()["intent"] == "compare_months"
    assert len(response.json()["data"]) == 2
    assert "change" in response.json()["data"][1]


def test_unsupported_question(client):
    response = client.post("/ask", json={"question": "Tell me a joke"})
    assert response.status_code == 200
    assert response.json()["success"] is False


def test_empty_question_validation(client):
    response = client.post("/ask", json={"question": ""})
    assert response.status_code == 422
